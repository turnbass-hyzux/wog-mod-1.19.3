package me.shedaniel.betterloadingscreen.impl;

public class Internals {
    public static JobManagerImpl manager;
}
