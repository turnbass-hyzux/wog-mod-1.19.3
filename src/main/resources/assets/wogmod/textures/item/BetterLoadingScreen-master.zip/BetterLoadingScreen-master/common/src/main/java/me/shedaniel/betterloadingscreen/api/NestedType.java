package me.shedaniel.betterloadingscreen.api;

public enum NestedType {
    SHOW_ALL,
    SHOW_ACTIVE,
}
