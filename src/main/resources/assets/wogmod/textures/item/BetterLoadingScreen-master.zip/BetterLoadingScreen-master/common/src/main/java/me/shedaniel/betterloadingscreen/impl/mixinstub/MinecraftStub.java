package me.shedaniel.betterloadingscreen.impl.mixinstub;

public interface MinecraftStub {
    void moveRenderOut();
    
    void moveRenderIn();
}
