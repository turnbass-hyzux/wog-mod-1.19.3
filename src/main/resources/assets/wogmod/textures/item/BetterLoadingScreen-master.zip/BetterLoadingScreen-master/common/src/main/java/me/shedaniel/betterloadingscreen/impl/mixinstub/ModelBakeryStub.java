package me.shedaniel.betterloadingscreen.impl.mixinstub;

import me.shedaniel.betterloadingscreen.api.step.SteppedTask;

public interface ModelBakeryStub {
    void betterloadingscreen$setBlockTask(SteppedTask task);
    
    SteppedTask betterloadingscreen$getBlockTask();
    
    void betterloadingscreen$setItemTask(SteppedTask task);
    
    SteppedTask betterloadingscreen$getItemTask();
}
