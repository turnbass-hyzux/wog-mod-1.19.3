# Better Loading Screen
This is Better Loading Screen mod, this imitates the old Forge 1.12.2 style loading screen, and is fully customisable! This supports Fabric & Forge.

## License
View the `LICENSE` file for the license.

## Why so many hacks?
Yes.

## Build
This project is built on Architectury.

### Prerequisites
- JDK 17

### Compile
After compilation, the mod will be placed in the `[loader]/build/libs` folder.
```
Unix-like Systems
./gradlew build

Windows
gradlew.bat build
```