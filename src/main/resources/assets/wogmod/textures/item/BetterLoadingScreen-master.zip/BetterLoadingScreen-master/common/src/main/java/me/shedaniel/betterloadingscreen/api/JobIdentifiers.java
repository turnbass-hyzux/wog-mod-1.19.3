package me.shedaniel.betterloadingscreen.api;

public interface JobIdentifiers {
    StatusIdentifier<Job> LOAD_GAME = StatusIdentifier.of("Loading Game");
}
