package me.shedaniel.betterloadingscreen.impl.mixinstub;

import me.shedaniel.betterloadingscreen.api.step.SteppedTask;

public interface StitcherStub {
    void betterloadingscreen$setActiveTask(SteppedTask activeTask);
}
