package me.shedaniel.betterloadingscreen.api;

public interface HasProgress {
    double getProgress();
}
